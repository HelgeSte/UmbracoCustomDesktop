export interface StatsModalType {
    id: number;
}